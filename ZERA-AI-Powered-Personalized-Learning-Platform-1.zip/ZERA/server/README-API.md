# ZERA — AI API Architecture (Backend Integration Guide)

This folder documents **how to connect a real AI provider to ZERA**.

It contains no keys, no secrets and no credentials — and neither does any file in the
`js/` folder. That is the entire point of this document.

---

## 1. The one rule

> **NEVER hard-code a secret API key into HTML, CSS or JavaScript.**

Anything shipped to the browser is public. View-source, DevTools → Sources, the network
tab, and any CDN cache all expose it. A key in `js/interactions.js` is a leaked key the
moment the site goes live, and leaked keys get abused and billed.

So the frontend never talks to an AI provider directly. It talks to **your** backend.

---

## 2. Architecture

```
┌──────────────┐        ┌──────────────────────┐        ┌────────────────────┐
│   Browser    │  HTTPS │   Your backend       │  HTTPS │   AI provider      │
│  (ZERA UI)   │ ─────► │   /api/ai/*          │ ─────► │  Gemini / Groq /   │
│              │ ◄───── │                      │ ◄───── │  Hugging Face …    │
└──────────────┘  JSON  └──────────────────────┘  JSON  └────────────────────┘
   no secrets            holds the API key             never sees your users
                         in an env variable
```

- The browser sends only the **user's question and context** (topic, syllabus id, mode).
- The backend attaches the key, calls the provider, and returns a plain JSON answer.
- The key exists in exactly one place: the server's environment.

### Trust boundary

| Layer | Holds secrets? | Notes |
| --- | --- | --- |
| `index.html`, `css/*`, `js/*` | **No** | Fully public. Assume anyone can read it. |
| Your backend process | **Yes** | Keys from environment variables only. |
| Provider | n/a | Receives requests from your server only. |

---

## 3. Where the frontend expects the API

`js/interactions.js` currently answers from a small **offline knowledge base** so the
demo works with no internet and no key. The function to replace is `askAI()`.

Swap its body for a `fetch` to your own route:

```js
// js/interactions.js  — replace the offline lookup with this
async function askAI(question, context = {}) {
  const res = await fetch('/api/ai/doubt', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    // Same-origin session cookie or a short-lived token — never a provider key
    credentials: 'same-origin',
    body: JSON.stringify({ question, context })
  });

  if (!res.ok) throw new Error('AI request failed: ' + res.status);
  const data = await res.json();
  return data.answer;          // { answer: "<html-safe string>" }
}
```

Nothing else in the frontend changes. The chat UI, quiz, planner and dashboard
assistant all route through `askAI()` / the endpoints below.

---

## 4. Suggested endpoints

| Method | Route | Purpose | Request body |
| --- | --- | --- | --- |
| `POST` | `/api/ai/doubt` | Doubt solver answer | `{ question, context }` |
| `POST` | `/api/ai/notes` | Topic notes | `{ topic, depth: "quick"\|"exam"\|"deep" }` |
| `POST` | `/api/ai/quiz` | Generate MCQs | `{ topic, count, difficulty }` |
| `POST` | `/api/ai/plan` | Weekly study plan | `{ syllabusId, hoursPerWeek, examDate }` |
| `POST` | `/api/ai/interview` | Mock interview turn | `{ round, questionId, answer }` |
| `POST` | `/api/syllabus/parse` | Parse an uploaded syllabus | `multipart/form-data` |
| `GET`  | `/api/progress` | Dashboard metrics | — |

All responses should be JSON with a stable shape and a plain `error` string on failure,
so the UI can show a real message instead of failing silently.

---

## 5. Reference implementation (Node + Express)

```js
// server/index.js
import express from 'express';
import rateLimit from 'express-rate-limit';

const app = express();
app.use(express.json({ limit: '128kb' }));
app.use(express.static('..'));                       // serves the ZERA frontend

// Never trust the client for volume
app.use('/api/', rateLimit({ windowMs: 60_000, max: 20 }));

const KEY   = process.env.AI_API_KEY;                // ← from the environment
const MODEL = process.env.AI_MODEL || 'gemini-2.0-flash';
if (!KEY) throw new Error('AI_API_KEY is not set');

app.post('/api/ai/doubt', async (req, res) => {
  const { question, context = {} } = req.body ?? {};

  if (typeof question !== 'string' || question.trim().length < 3) {
    return res.status(400).json({ error: 'A question is required.' });
  }
  if (question.length > 1000) {
    return res.status(413).json({ error: 'Question is too long.' });
  }

  const system =
    'You are ZERA, a free study assistant for students in any academic field. ' +
    'Answer with a short definition, the mechanism, one worked example, and a check ' +
    'question. Use the student syllabus context when provided. Never mention pricing, ' +
    'subscriptions or premium tiers — ZERA is completely free for students.';

  try {
    const r = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: system }] },
          contents: [{ parts: [{ text: `${question}\n\nContext: ${JSON.stringify(context)}` }] }]
        })
      }
    );

    if (!r.ok) return res.status(502).json({ error: 'Upstream AI provider error.' });

    const json = await r.json();
    const answer = json?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
    res.json({ answer });
  } catch {
    res.status(500).json({ error: 'Could not reach the AI service.' });
  }
});

app.listen(process.env.PORT || 3000);
```

### Python equivalent (FastAPI)

```python
# server/main.py
import os, httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

KEY = os.environ["AI_API_KEY"]          # raises at boot if missing — good
app = FastAPI()

class Doubt(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    context: dict = {}

@app.post("/api/ai/doubt")
async def doubt(body: Doubt):
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {KEY}"},
            json={
                "model": os.getenv("AI_MODEL", "llama-3.3-70b-versatile"),
                "messages": [
                    {"role": "system", "content": "You are ZERA, a free study assistant."},
                    {"role": "user", "content": body.question},
                ],
            },
        )
    if r.status_code >= 400:
        raise HTTPException(502, "Upstream AI provider error.")
    return {"answer": r.json()["choices"][0]["message"]["content"]}
```

---

## 6. Provider options with a free tier

Free tiers, model names and limits change often — always check the provider's current
documentation before committing to one.

| Provider | Good for | Notes |
| --- | --- | --- |
| **Google Gemini API** | General explanations, long context, vision (syllabus photos) | Generous free tier; `x-goog-api-key` header |
| **Groq** | Very fast responses for chat-style doubt solving | OpenAI-compatible request shape |
| **Hugging Face Inference** | Open-weight models, embeddings, small classifiers | Good for search/similarity, cold starts possible |
| **Other free-tier / OpenAI-compatible gateways** | Drop-in swaps | Keep the same server route so the frontend never changes |
| **Local models (Ollama, llama.cpp)** | Zero cost, full privacy, offline dev | Needs hardware; no key at all |

Because every call goes through your one `/api/ai/*` layer, switching provider is a
server-side change. The frontend is unaffected.

---

## 7. Environment variables

Copy `.env.example` (in the project root) to `.env` and fill it in. **Never commit `.env`.**

```
AI_PROVIDER=gemini
AI_API_KEY=your_key_here
AI_MODEL=gemini-2.0-flash
PORT=3000
ALLOWED_ORIGIN=https://your-domain.example
```

Add to `.gitignore`:

```
.env
.env.*
!.env.example
node_modules/
__pycache__/
```

---

## 8. Security checklist before going live

- [ ] No key, token or secret appears anywhere in `js/`, `css/` or any `.html` file
- [ ] `.env` is git-ignored; `.env.example` contains placeholders only
- [ ] Keys are read from the environment, and the server refuses to boot without them
- [ ] Rate limiting on every `/api/` route (per IP and, once you have auth, per user)
- [ ] Input length caps and type validation on every request body
- [ ] CORS restricted to your own origin — not `*`
- [ ] Provider errors mapped to generic messages; never forward raw upstream errors
- [ ] Request logging without prompt bodies, and without keys
- [ ] Keys rotated if a repository, log or screenshot ever exposed one
- [ ] Timeouts and a fallback message so a provider outage degrades gracefully
- [ ] HTTPS everywhere; secure, `HttpOnly`, `SameSite` cookies if you add sessions

---

## 9. Cost control

ZERA is free for students, so the backend must be the thing that keeps it sustainable:

- Cache generated notes and quizzes per topic — most students ask for the same topics.
- Prefer smaller/faster models for quizzes and short answers; reserve larger models for
  deep explanations.
- Cap tokens per request and requests per user per day.
- Store parsed syllabus structure once instead of re-parsing on each visit.

---

*ZERA — AI-Powered Personalized Learning Platform · 100% Free for Students*
