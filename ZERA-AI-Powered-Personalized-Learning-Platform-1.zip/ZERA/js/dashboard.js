/* ==========================================================================
   ZERA — dashboard.js
   Dashboard-only behaviour: section switching, syllabus tracker,
   weak-topic drilldown, activity feed timestamps, mini AI assistant.
   All data is local sample data — no account, no network calls.
   ========================================================================== */

(function () {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const toast = (t, d, k) => (window.ZERA && window.ZERA.toast ? window.ZERA.toast(t, d, k) : null);

  if (!$('[data-dashboard]')) return;

  /* ------------------------------------------------------------------ *
   * Sidebar section switching (single-page dashboard sections)
   * ------------------------------------------------------------------ */
  function initSections() {
    const links = $$('a[data-section]');
    const sideLinks = $$('.side a[data-section]');
    const sections = $$('[data-section-panel]');
    if (!links.length || !sections.length) return;

    const show = (name, push) => {
      const target = sections.find((s) => s.dataset.sectionPanel === name);
      if (!target) return;
      sections.forEach((s) => { s.hidden = s !== target; });
      sideLinks.forEach((l) => {
        const on = l.dataset.section === name;
        l.classList.toggle('active', on);
        if (on) l.setAttribute('aria-current', 'page');
        else l.removeAttribute('aria-current');
      });
      if (push) history.replaceState(null, '', '#' + name);
      window.scrollTo({ top: 0, behavior: window.ZERA && window.ZERA.reduceMotion ? 'auto' : 'smooth' });
    };

    links.forEach((l) => {
      l.addEventListener('click', (e) => {
        e.preventDefault();
        show(l.dataset.section, true);
      });
    });

    const initial = (location.hash || '').replace('#', '');
    show(sections.some((s) => s.dataset.sectionPanel === initial) ? initial : sections[0].dataset.sectionPanel, false);
  }

  /* ------------------------------------------------------------------ *
   * Syllabus unit tracker — toggling a unit updates the overall ring
   * ------------------------------------------------------------------ */
  function initSyllabus() {
    const units = $$('[data-unit]');
    if (!units.length) return;
    const ringVal = $('[data-ring-syllabus]');
    const ringTxt = $('[data-ring-syllabus-text]');
    const countTxt = $('[data-syllabus-count]');
    const C = 339.29;

    const paint = () => {
      const done = units.filter((u) => u.dataset.unit === 'done').length;
      const pct = Math.round((done / units.length) * 100);
      if (ringVal) ringVal.style.strokeDashoffset = String(C - (C * pct) / 100);
      if (ringTxt) ringTxt.textContent = pct + '%';
      if (countTxt) countTxt.textContent = done + ' of ' + units.length + ' units complete';
      return pct;
    };

    units.forEach((u) => {
      const btn = $('[data-unit-toggle]', u);
      if (!btn) return;
      btn.addEventListener('click', () => {
        const done = u.dataset.unit === 'done';
        u.dataset.unit = done ? 'todo' : 'done';
        const tag = $('.tag', u);
        if (tag) {
          // A reopened unit returns to its real coverage state, not a blanket label.
          const bar = $('.bar > i', u);
          const cover = bar ? parseInt(bar.dataset.w || '0', 10) : 0;
          if (!done) {
            tag.textContent = 'Complete';
            tag.className = 'tag mi';
          } else if (cover === 0) {
            tag.textContent = 'Not started';
            tag.className = 'tag';
          } else {
            tag.textContent = 'In progress';
            tag.className = 'tag am';
          }
        }
        btn.textContent = done ? 'Mark complete' : 'Reopen unit';
        const pct = paint();
        toast(done ? 'Unit reopened' : 'Unit marked complete', 'Syllabus now at ' + pct + '%', done ? 'info' : 'ok');
      });
    });

    paint();
  }

  /* ------------------------------------------------------------------ *
   * Weak topics — "Practice now" opens the matching study action
   * ------------------------------------------------------------------ */
  function initWeakTopics() {
    $$('[data-practice]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const topic = btn.dataset.practice;
        toast('Practice set queued', topic + ' \u00B7 10 adaptive questions ready in the Quiz tab.', 'ok');
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * Relative timestamps in the activity feed
   * ------------------------------------------------------------------ */
  function initActivity() {
    const rel = (mins) => {
      if (mins < 1) return 'just now';
      if (mins < 60) return mins + ' min ago';
      const h = Math.floor(mins / 60);
      if (h < 24) return h + (h === 1 ? ' hour ago' : ' hours ago');
      const d = Math.floor(h / 24);
      return d + (d === 1 ? ' day ago' : ' days ago');
    };
    $$('[data-ago]').forEach((el) => {
      el.textContent = rel(parseInt(el.dataset.ago, 10) || 0);
    });
  }

  /* ------------------------------------------------------------------ *
   * Study streak calendar strip
   * ------------------------------------------------------------------ */
  function initStreak() {
    const host = $('[data-streak-grid]');
    if (!host) return;
    // 28-day sample pattern: 1 = studied, 0 = missed
    const pattern = [
      1, 1, 0, 1, 1, 1, 1,
      1, 0, 1, 1, 1, 1, 0,
      1, 1, 1, 1, 0, 1, 1,
      1, 1, 1, 1, 1, 1, 1
    ];
    host.innerHTML = '';
    pattern.forEach((on, idx) => {
      const cell = document.createElement('span');
      cell.style.cssText =
        'width:100%;aspect-ratio:1;border-radius:5px;border:1px solid ' +
        (on ? 'rgba(52,211,153,.45)' : 'rgba(255,255,255,.09)') +
        ';background:' +
        (on ? 'rgba(52,211,153,' + (0.22 + (idx % 3) * 0.14).toFixed(2) + ')' : 'rgba(255,255,255,.03)') +
        ';';
      cell.title = on ? 'Studied' : 'No session';
      host.appendChild(cell);
    });
  }

  /* ------------------------------------------------------------------ *
   * Compact AI assistant panel (uses the shared ZERA.askAI demo brain)
   * ------------------------------------------------------------------ */
  function initAssistant() {
    const panel = $('[data-assistant]');
    if (!panel) return;
    const log = $('.chat-log', panel);
    const form = $('.chat-input', panel);
    const input = $('input', panel);
    if (!log || !form || !input) return;

    const push = (who, html) => {
      const el = document.createElement('div');
      el.className = 'msg ' + (who === 'me' ? 'me' : 'ai');
      el.innerHTML =
        '<div class="who" aria-hidden="true">' + (who === 'me' ? 'YOU' : 'Z') + '</div>' +
        '<div class="bubble">' + html + '</div>';
      log.appendChild(el);
      log.scrollTop = log.scrollHeight;
      return el;
    };

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const q = input.value.trim();
      if (!q) return;
      input.value = '';
      push('me', q.replace(/[<>&]/g, ''));
      const t = push('ai', '<span class="typing"><i></i><i></i><i></i></span>');
      const ask = (window.ZERA && window.ZERA.askAI) || (() => Promise.resolve('<p>Assistant demo unavailable.</p>'));
      const html = await ask(q);
      const b = $('.bubble', t);
      if (b) b.innerHTML = html;
      log.scrollTop = log.scrollHeight;
    });

    $$('.chat-suggest button', panel).forEach((b) => {
      b.addEventListener('click', () => {
        input.value = b.textContent.trim();
        form.dispatchEvent(new Event('submit'));
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * Recommended resources — save toggle
   * ------------------------------------------------------------------ */
  function initSaves() {
    $$('[data-save]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const on = btn.dataset.saved === '1';
        btn.dataset.saved = on ? '0' : '1';
        btn.textContent = on ? 'Save' : 'Saved';
        btn.classList.toggle('btn-primary', !on);
        btn.classList.toggle('btn-ghost', on);
        toast(on ? 'Removed from saved' : 'Saved for later', btn.dataset.save, on ? 'info' : 'ok');
      });
    });
  }

  function boot() {
    initSections();
    initSyllabus();
    initWeakTopics();
    initActivity();
    initStreak();
    initAssistant();
    initSaves();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
