/* ==========================================================================
   ZERA — interactions.js
   Interactive prototypes: AI Doubt Solver chat, Smart Quiz engine,
   weekly Study Planner, contact form validation.

   IMPORTANT: every AI response here comes from a local scripted knowledge
   base so the demo works fully offline. To make it live, point
   `ZERA.askAI()` at your own backend route (see server/README-API.md).
   No API keys are ever stored in this file.
   ========================================================================== */

(function () {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const toast = (t, d, k) => (window.ZERA && window.ZERA.toast ? window.ZERA.toast(t, d, k) : null);

  /* ================================================================== *
   * 1. AI DOUBT SOLVER — scripted demo brain
   * ================================================================== */

  const KB = [
    {
      keys: ['recursion', 'recursive'],
      html:
        '<p>Think of recursion as a function that solves a <strong>smaller version of the same problem</strong>, then trusts itself to finish the rest.</p>' +
        '<ul><li><strong>Base case</strong> — the smallest input where you already know the answer, so the function stops.</li>' +
        '<li><strong>Recursive step</strong> — shrink the problem and call yourself again.</li></ul>' +
        '<pre>function factorial(n) {\n  if (n <= 1) return 1;   // base case\n  return n * factorial(n - 1); // recursive step\n}</pre>' +
        '<p>Real-world picture: standing in a queue and asking the person ahead "what number are you?" until someone at the front simply says "1".</p>'
    },
    {
      keys: ['normalization', 'normalisation', '1nf', '2nf', '3nf', 'dbms', 'database'],
      html:
        '<p>Normalization organises a database so the same fact is stored in exactly one place.</p>' +
        '<ul><li><strong>1NF</strong> — every cell holds a single value, no repeating groups.</li>' +
        '<li><strong>2NF</strong> — 1NF plus every non-key column depends on the <em>whole</em> primary key.</li>' +
        '<li><strong>3NF</strong> — 2NF plus no non-key column depends on another non-key column.</li></ul>' +
        '<p>Why it matters: fewer duplicate rows means fewer update anomalies, and your exam answers get much easier to justify.</p>'
    },
    {
      keys: ['photosynthesis', 'chlorophyll'],
      html:
        '<p>Photosynthesis is how a plant turns light into food.</p>' +
        '<pre>6CO2 + 6H2O + light -> C6H12O6 + 6O2</pre>' +
        '<ul><li><strong>Light reactions</strong> happen in the thylakoid membrane and produce ATP and NADPH.</li>' +
        '<li><strong>Calvin cycle</strong> happens in the stroma and fixes CO2 into glucose.</li></ul>' +
        '<p>Memory hook: light reactions <em>capture</em> energy, the Calvin cycle <em>spends</em> it.</p>'
    },
    {
      keys: ['derivative', 'differentiation', 'calculus', 'limit'],
      html:
        '<p>A derivative measures how fast something changes right now — the slope of the curve at a single point.</p>' +
        '<pre>d/dx (x^n)   = n·x^(n-1)\nd/dx (sin x) = cos x\nd/dx (e^x)   = e^x</pre>' +
        '<ul><li>Position differentiates to velocity, velocity differentiates to acceleration.</li>' +
        '<li>Set the derivative to zero to find maxima and minima — that is where most exam marks live.</li></ul>'
    },
    {
      keys: ['demand', 'supply', 'elasticity', 'economics', 'commerce'],
      html:
        '<p>Price elasticity of demand tells you how sensitive buyers are to a price change.</p>' +
        '<pre>Ed = (% change in quantity) / (% change in price)</pre>' +
        '<ul><li><strong>Ed &gt; 1</strong> — elastic, buyers react strongly (cinema tickets).</li>' +
        '<li><strong>Ed &lt; 1</strong> — inelastic, buyers barely react (salt, medicine).</li></ul>' +
        '<p>Exam tip: always state whether the good has close substitutes — that is usually the deciding factor.</p>'
    },
    {
      keys: ['oop', 'inheritance', 'polymorphism', 'encapsulation', 'class', 'object'],
      html:
        '<p>Object-oriented programming groups data and the behaviour that acts on it into one unit.</p>' +
        '<ul><li><strong>Encapsulation</strong> — hide internals, expose a clean interface.</li>' +
        '<li><strong>Inheritance</strong> — a child class reuses a parent class.</li>' +
        '<li><strong>Polymorphism</strong> — one call, many behaviours depending on the object.</li>' +
        '<li><strong>Abstraction</strong> — show what it does, not how it does it.</li></ul>' +
        '<pre>class Shape { area() { return 0; } }\nclass Circle extends Shape {\n  constructor(r) { super(); this.r = r; }\n  area() { return Math.PI * this.r ** 2; }\n}</pre>'
    },
    {
      keys: ['interview', 'hr round', 'introduce yourself', 'tell me about'],
      html:
        '<p>For "tell me about yourself", use a three-beat structure and keep it under 90 seconds.</p>' +
        '<ul><li><strong>Now</strong> — who you are and what you are studying.</li>' +
        '<li><strong>Proof</strong> — one project or result with a concrete detail.</li>' +
        '<li><strong>Next</strong> — why this specific role fits what you are building.</li></ul>' +
        '<p>Avoid listing your whole CV. Pick the one story you can defend under follow-up questions.</p>'
    },
    {
      keys: ['big o', 'complexity', 'time complexity', 'sorting'],
      html:
        '<p>Big-O describes how work grows as input grows — it ignores constants on purpose.</p>' +
        '<pre>O(1)      lookup in a hash map\nO(log n)  binary search\nO(n)      one pass over an array\nO(n log n) merge sort, quick sort (average)\nO(n^2)    nested loops, bubble sort</pre>' +
        '<p>Quick rule for exams: count how many times the innermost statement runs, then drop constants and lower-order terms.</p>'
    },
    {
      keys: ['study plan', 'revision', 'time table', 'timetable', 'how to study'],
      html:
        '<p>A plan that actually survives the week looks like this:</p>' +
        '<ul><li><strong>Two focus blocks a day</strong> of 50 minutes each, on your weakest topic first.</li>' +
        '<li><strong>Active recall</strong> — close the notes and write what you remember before re-reading.</li>' +
        '<li><strong>Spaced review</strong> — revisit on day 1, day 3, day 7.</li>' +
        '<li><strong>One mixed test</strong> per week so you practise switching topics.</li></ul>' +
        '<p>Open the Study Plan tab and mark tasks complete as you go — the planner keeps your streak.</p>'
    }
  ];

  const FALLBACK =
    '<p>Good question. Here is how I would break it down:</p>' +
    '<ul><li><strong>Define it</strong> in one plain sentence, no jargon.</li>' +
    '<li><strong>Find the mechanism</strong> — what causes what, and in which order.</li>' +
    '<li><strong>Anchor it</strong> with one worked example or diagram you can redraw from memory.</li>' +
    '<li><strong>Test it</strong> — write the answer without looking, then check the gaps.</li></ul>' +
    '<p>This demo runs on a small offline knowledge base. Try asking about <em>recursion</em>, ' +
    '<em>normalization</em>, <em>photosynthesis</em>, <em>derivatives</em>, <em>elasticity</em>, ' +
    '<em>OOP</em>, <em>Big-O</em> or <em>interview prep</em>.';

  /**
   * askAI(question) -> Promise<string of HTML>
   * Replace the body of this function with a fetch() to your own backend
   * (never call a provider directly from the browser — your key would leak).
   *
   *   const r = await fetch('/api/ask', {
   *     method: 'POST',
   *     headers: { 'Content-Type': 'application/json' },
   *     body: JSON.stringify({ question })
   *   });
   *   return (await r.json()).answerHtml;
   */
  function askAI(question) {
    const q = String(question || '').toLowerCase();
    const hit = KB.find((entry) => entry.keys.some((k) => q.includes(k)));
    const delay = reduce ? 120 : 700 + Math.random() * 700;
    return new Promise((resolve) => {
      setTimeout(() => resolve(hit ? hit.html : FALLBACK), delay);
    });
  }

  function initChat(root) {
    const log = $('.chat-log', root);
    const form = $('.chat-input', root);
    const input = $('input', form || root);
    if (!log || !form || !input) return;

    let busy = false;

    const push = (who, html) => {
      const wrap = document.createElement('div');
      wrap.className = 'msg ' + (who === 'me' ? 'me' : 'ai');
      wrap.innerHTML =
        '<div class="who" aria-hidden="true">' + (who === 'me' ? 'YOU' : 'Z') + '</div>' +
        '<div class="bubble">' + html + '</div>';
      log.appendChild(wrap);
      log.scrollTop = log.scrollHeight;
      return wrap;
    };

    const ask = async (text) => {
      if (busy) return;
      const q = String(text || '').trim();
      if (!q) return;
      busy = true;
      input.value = '';
      push('me', escapeHtml(q));

      const thinking = push('ai', '<span class="typing" role="status" aria-label="ZERA AI is thinking"><i></i><i></i><i></i></span>');
      const html = await askAI(q);
      const bubble = $('.bubble', thinking);
      if (bubble) bubble.innerHTML = html;
      log.scrollTop = log.scrollHeight;
      busy = false;
    };

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      ask(input.value);
    });

    $$('.chat-suggest button', root).forEach((b) => {
      b.addEventListener('click', () => ask(b.textContent.trim()));
    });

    // Seed the transcript once the panel is first seen
    const seed = () => {
      if (log.dataset.seeded) return;
      log.dataset.seeded = '1';
      push('me', 'Explain recursion like I&rsquo;m a beginner.');
      const t = push('ai', '<span class="typing"><i></i><i></i><i></i></span>');
      askAI('recursion').then((html) => {
        const b = $('.bubble', t);
        if (b) b.innerHTML = html;
      });
    };

    if ('IntersectionObserver' in window) {
      const io = new IntersectionObserver((es) => {
        es.forEach((e) => { if (e.isIntersecting) { seed(); io.disconnect(); } });
      }, { threshold: 0.25 });
      io.observe(root);
    } else {
      seed();
    }
  }

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* ================================================================== *
   * 2. SMART QUIZ ENGINE
   * ================================================================== */

  const QUIZ = [
    {
      subject: 'Data Structures',
      diff: 'Medium',
      q: 'What is the average-case time complexity of searching a balanced binary search tree?',
      opts: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
      a: 1,
      why: 'Each comparison discards half of the remaining nodes, so the height — and the search cost — grows logarithmically with the number of nodes.'
    },
    {
      subject: 'DBMS',
      diff: 'Easy',
      q: 'A relation is in 1NF when:',
      opts: [
        'Every non-key attribute depends on the whole key',
        'Every cell contains a single atomic value',
        'There are no transitive dependencies',
        'All foreign keys are indexed'
      ],
      a: 1,
      why: 'First Normal Form only requires atomic values with no repeating groups. Whole-key dependency is 2NF and removing transitive dependency is 3NF.'
    },
    {
      subject: 'Operating Systems',
      diff: 'Medium',
      q: 'Thrashing in an operating system occurs when:',
      opts: [
        'The CPU runs at 100% utilisation',
        'Two processes deadlock on a shared lock',
        'Processes spend more time paging than executing',
        'The disk cache is disabled'
      ],
      a: 2,
      why: 'Thrashing happens when too little physical memory is allocated per process, so page faults dominate and useful CPU work collapses.'
    },
    {
      subject: 'Mathematics',
      diff: 'Easy',
      q: 'What is the derivative of \u0192(x) = 3x\u00B3 \u2212 5x?',
      opts: ['9x\u00B2 \u2212 5', '3x\u00B2 \u2212 5', '9x\u00B2 \u2212 5x', '6x \u2212 5'],
      a: 0,
      why: 'Apply the power rule term by term: d/dx(3x\u00B3) = 9x\u00B2 and d/dx(\u22125x) = \u22125.'
    },
    {
      subject: 'Computer Networks',
      diff: 'Hard',
      q: 'Which layer of the OSI model is responsible for reliable end-to-end delivery?',
      opts: ['Network layer', 'Transport layer', 'Session layer', 'Data link layer'],
      a: 1,
      why: 'The transport layer (TCP) handles segmentation, acknowledgement, retransmission and flow control between end systems.'
    }
  ];

  function initQuiz(root) {
    const meta = $('[data-quiz-meta]', root);
    const qEl = $('[data-quiz-q]', root);
    const optsEl = $('[data-quiz-opts]', root);
    const barEl = $('[data-quiz-bar]', root);
    const countEl = $('[data-quiz-count]', root);
    const scoreEl = $('[data-quiz-score]', root);
    const explainEl = $('[data-quiz-explain]', root);
    const nextBtn = $('[data-quiz-next]', root);
    const stage = $('[data-quiz-stage]', root);
    const resultEl = $('[data-quiz-result]', root);
    if (!qEl || !optsEl || !nextBtn) return;

    let i = 0;
    let score = 0;
    let locked = false;

    const KEYS = ['A', 'B', 'C', 'D'];

    function render() {
      const item = QUIZ[i];
      locked = false;
      if (meta) {
        meta.innerHTML =
          '<span class="chip">' + item.subject + '</span>' +
          '<span class="tag ' + (item.diff === 'Easy' ? 'mi' : item.diff === 'Medium' ? 'am' : 'ro') + '">' + item.diff + '</span>';
      }
      qEl.textContent = item.q;
      if (countEl) countEl.textContent = 'Question ' + (i + 1) + ' of ' + QUIZ.length;
      if (barEl) barEl.style.width = ((i / QUIZ.length) * 100) + '%';
      if (explainEl) { explainEl.hidden = true; explainEl.innerHTML = ''; }
      nextBtn.disabled = true;
      nextBtn.textContent = i === QUIZ.length - 1 ? 'See result' : 'Next question';

      optsEl.innerHTML = '';
      item.opts.forEach((text, idx) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'opt';
        b.innerHTML = '<span class="key" aria-hidden="true">' + KEYS[idx] + '</span><span>' + text + '</span>';
        b.addEventListener('click', () => choose(idx, b));
        optsEl.appendChild(b);
      });
    }

    function choose(idx, btn) {
      if (locked) return;
      locked = true;
      const item = QUIZ[i];
      const buttons = $$('.opt', optsEl);
      buttons.forEach((b, n) => {
        b.disabled = true;
        if (n === item.a) b.classList.add('correct');
        else if (n === idx) b.classList.add('wrong');
        else b.classList.add('dim');
      });
      if (idx === item.a) {
        score += 1;
        toast('Correct', item.subject + ' \u2014 nice work.', 'ok');
      } else {
        toast('Not quite', 'Correct answer: ' + KEYS[item.a] + '. Read the explanation.', 'warn');
      }
      if (scoreEl) scoreEl.textContent = score + '/' + QUIZ.length;
      if (explainEl) {
        explainEl.hidden = false;
        explainEl.innerHTML = '<b>Why:</b> ' + item.why;
      }
      nextBtn.disabled = false;
      nextBtn.focus();
    }

    function finish() {
      const pct = Math.round((score / QUIZ.length) * 100);
      if (barEl) barEl.style.width = '100%';
      if (stage) stage.hidden = true;
      if (!resultEl) return;
      resultEl.hidden = false;
      const verdict =
        pct >= 80 ? 'Strong grasp \u2014 move to harder sets.' :
        pct >= 50 ? 'Solid base \u2014 revise the missed topics.' :
        'Worth one more pass through the fundamentals.';
      resultEl.innerHTML =
        '<div class="result">' +
        '<div class="score grad-text">' + pct + '%</div>' +
        '<p class="lead" style="margin:12px auto 0">You answered ' + score + ' of ' + QUIZ.length +
        ' correctly. ' + verdict + '</p>' +
        '<div class="hero-actions" style="justify-content:center;margin-top:24px">' +
        '<button class="btn btn-primary" type="button" data-quiz-restart>Retry quiz</button>' +
        '<a class="btn btn-ghost" href="dashboard.html">Open dashboard</a>' +
        '</div></div>';
      $('[data-quiz-restart]', resultEl).addEventListener('click', () => {
        i = 0; score = 0;
        if (scoreEl) scoreEl.textContent = '0/' + QUIZ.length;
        resultEl.hidden = true;
        if (stage) stage.hidden = false;
        render();
      });
    }

    nextBtn.addEventListener('click', () => {
      if (i === QUIZ.length - 1) return finish();
      i += 1;
      render();
    });

    if (scoreEl) scoreEl.textContent = '0/' + QUIZ.length;
    render();
  }

  /* ================================================================== *
   * 3. WEEKLY STUDY PLANNER
   * ================================================================== */

  function initPlanner(root) {
    const tasks = $$('.task', root);
    if (!tasks.length) return;
    const readout = $('[data-plan-readout]', root);
    const bar = $('[data-plan-bar]', root);

    const update = () => {
      const done = tasks.filter((t) => t.classList.contains('done')).length;
      const pct = Math.round((done / tasks.length) * 100);
      if (readout) readout.textContent = done + ' of ' + tasks.length + ' sessions done \u00B7 ' + pct + '%';
      if (bar) bar.style.width = pct + '%';
      return { done, pct };
    };

    tasks.forEach((t) => {
      t.setAttribute('role', 'checkbox');
      t.setAttribute('aria-checked', t.classList.contains('done') ? 'true' : 'false');
      const toggle = () => {
        const on = t.classList.toggle('done');
        t.setAttribute('aria-checked', on ? 'true' : 'false');
        const { pct } = update();
        const name = ($('.tx b', t) || {}).textContent || 'Session';
        if (on) toast('Session complete', name + ' \u00B7 week at ' + pct + '%', 'ok');
      };
      t.addEventListener('click', toggle);
      t.addEventListener('keydown', (e) => {
        if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(); }
      });
    });

    update();
  }

  /* ================================================================== *
   * 4. CONTACT FORM (client-side validation only, no backend)
   * ================================================================== */

  function initContactForm(form) {
    const setErr = (name, msg) => {
      const box = form.querySelector('[data-err="' + name + '"]');
      if (box) box.textContent = msg || '';
    };

    form.setAttribute('novalidate', 'novalidate');

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = new FormData(form);
      const name = String(data.get('name') || '').trim();
      const email = String(data.get('email') || '').trim();
      const subject = String(data.get('subject') || '').trim();
      const message = String(data.get('message') || '').trim();
      let ok = true;

      setErr('name', ''); setErr('email', ''); setErr('subject', ''); setErr('message', '');

      if (name.length < 2) { setErr('name', 'Please enter your name.'); ok = false; }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { setErr('email', 'Enter a valid email address.'); ok = false; }
      if (!subject) { setErr('subject', 'Choose what your message is about.'); ok = false; }
      if (message.length < 12) { setErr('message', 'Add a little more detail (12+ characters).'); ok = false; }

      if (!ok) {
        toast('Check the form', 'Some fields still need attention.', 'warn');
        const firstErr = form.querySelector('.err:not(:empty)');
        if (firstErr) {
          const fld = firstErr.closest('.fld');
          const control = fld && fld.querySelector('input, select, textarea');
          if (control) control.focus();
        }
        return;
      }

      const btn = form.querySelector('button[type="submit"]');
      if (btn) { btn.disabled = true; btn.textContent = 'Sending\u2026'; }

      setTimeout(() => {
        if (btn) { btn.disabled = false; btn.textContent = 'Send message'; }
        form.reset();
        toast('Message captured locally', 'This build has no mail backend \u2014 wire up /api/contact to deliver it.', 'info', 5200);
      }, 800);
    });

    form.querySelectorAll('input, select, textarea').forEach((c) => {
      c.addEventListener('input', () => setErr(c.name, ''));
    });
  }

  /* ================================================================== *
   * Boot
   * ================================================================== */
  function boot() {
    $$('[data-chat]').forEach(initChat);
    $$('[data-quiz]').forEach(initQuiz);
    $$('[data-planner]').forEach(initPlanner);
    $$('[data-contact-form]').forEach(initContactForm);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.ZERA = Object.assign(window.ZERA || {}, { askAI: askAI, quizBank: QUIZ });
})();
