/* ==========================================================================
   ZERA — main.js
   Global site behaviour: navigation, scroll reveal, counters, progress
   animation, FAQ accordion, card spotlight, toasts, year stamp.
   No external dependencies. Safe to load on every page.
   ========================================================================== */

(function () {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------ *
   * Toast notifications (exposed globally as ZERA.toast)
   * ------------------------------------------------------------------ */
  const ICONS = {
    ok: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 16v-5M12 8h.01"/></svg>',
    warn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 3.7 1.9 18a2 2 0 0 0 1.7 3h16.8a2 2 0 0 0 1.7-3L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>'
  };

  function toastHost() {
    let host = $('.toasts');
    if (!host) {
      host = document.createElement('div');
      host.className = 'toasts';
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    return host;
  }

  function toast(title, detail, kind = 'ok', ms = 3800) {
    const host = toastHost();
    const el = document.createElement('div');
    el.className = 'toast ' + kind;
    el.innerHTML =
      (ICONS[kind] || ICONS.info) +
      '<div><strong>' + title + '</strong>' +
      (detail ? '<span>' + detail + '</span>' : '') +
      '</div>';
    host.appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      el.addEventListener('animationend', () => el.remove(), { once: true });
      setTimeout(() => el.remove(), 600);
    }, ms);
  }

  /* ------------------------------------------------------------------ *
   * Sticky navbar + mobile menu
   * ------------------------------------------------------------------ */
  function initNav() {
    const nav = $('.nav');
    const burger = $('.burger');
    const panel = $('.mobile-panel');

    if (nav) {
      const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 12);
      onScroll();
      window.addEventListener('scroll', onScroll, { passive: true });
    }

    if (burger && panel) {
      const close = () => {
        panel.classList.remove('open');
        burger.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      };
      burger.addEventListener('click', () => {
        const open = panel.classList.toggle('open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
        document.body.style.overflow = open ? 'hidden' : '';
      });
      $$('a, button', panel).forEach((a) => a.addEventListener('click', close));
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && panel.classList.contains('open')) {
          close();
          burger.focus();
        }
      });
      window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) close();
      });
    }
  }

  /* ------------------------------------------------------------------ *
   * Scroll reveal (IntersectionObserver)
   * ------------------------------------------------------------------ */
  function initReveal() {
    const targets = $$('[data-reveal], [data-reveal-group]');
    if (!targets.length) return;

    if (reduceMotion || !('IntersectionObserver' in window)) {
      targets.forEach((t) => t.classList.add('in'));
      return;
    }

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('in');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' }
    );
    targets.forEach((t) => io.observe(t));
  }

  /* ------------------------------------------------------------------ *
   * Animated counters — <b data-count="98" data-suffix="%">
   * ------------------------------------------------------------------ */
  function runCounter(el) {
    const target = parseFloat(el.dataset.count || '0');
    const suffix = el.dataset.suffix || '';
    const prefix = el.dataset.prefix || '';
    const decimals = (el.dataset.count || '').includes('.') ? 1 : 0;

    if (reduceMotion) {
      el.textContent = prefix + target.toFixed(decimals) + suffix;
      return;
    }

    const dur = 1500;
    const start = performance.now();
    const tick = (now) => {
      const p = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = prefix + (target * eased).toFixed(decimals) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  function initCounters() {
    const els = $$('[data-count]');
    if (!els.length) return;
    if (!('IntersectionObserver' in window)) return els.forEach(runCounter);

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            runCounter(e.target);
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.4 }
    );
    els.forEach((el) => io.observe(el));
  }

  /* ------------------------------------------------------------------ *
   * Progress bars + rings animate into view
   * ------------------------------------------------------------------ */
  function initProgress() {
    const bars = $$('.bar > i[data-w]');
    const rings = $$('.ring .val[data-p]');
    const all = bars.concat(rings);
    if (!all.length) return;

    const fill = (el) => {
      if (el.dataset.w !== undefined) {
        el.style.width = Math.max(0, Math.min(100, parseFloat(el.dataset.w))) + '%';
      } else {
        const C = 339.29; // 2πr, r = 54
        const p = Math.max(0, Math.min(100, parseFloat(el.dataset.p)));
        el.style.strokeDashoffset = String(C - (C * p) / 100);
      }
    };

    if (!('IntersectionObserver' in window)) return all.forEach(fill);

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setTimeout(() => fill(e.target), 120);
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.35 }
    );
    all.forEach((el) => io.observe(el));
  }

  /* ------------------------------------------------------------------ *
   * CSS bar chart columns — <i data-h="72" data-v="72">
   * ------------------------------------------------------------------ */
  function initColumns() {
    const groups = $$('.chart-cols');
    if (!groups.length) return;

    const run = (group) => {
      $$('.col i', group).forEach((bar, i) => {
        const h = Math.max(0, Math.min(100, parseFloat(bar.dataset.h || '0')));
        setTimeout(() => { bar.style.height = h + '%'; }, i * 80);
      });
    };

    if (!('IntersectionObserver' in window)) return groups.forEach(run);
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) { run(e.target); io.unobserve(e.target); }
        });
      },
      { threshold: 0.3 }
    );
    groups.forEach((g) => io.observe(g));
  }

  /* ------------------------------------------------------------------ *
   * Card spotlight follow (pointer only)
   * ------------------------------------------------------------------ */
  function initSpotlight() {
    if (reduceMotion || !window.matchMedia('(hover: hover)').matches) return;
    $$('.card').forEach((card) => {
      card.addEventListener('pointermove', (e) => {
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', ((e.clientX - r.left) / r.width) * 100 + '%');
        card.style.setProperty('--my', ((e.clientY - r.top) / r.height) * 100 + '%');
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * FAQ accordion
   * ------------------------------------------------------------------ */
  function initFaq() {
    $$('.faq-item').forEach((item) => {
      const btn = $('.faq-q', item);
      const ans = $('.faq-a', item);
      if (!btn || !ans) return;

      const id = ans.id || 'faq-a-' + Math.random().toString(36).slice(2, 8);
      ans.id = id;
      btn.setAttribute('aria-expanded', 'false');
      btn.setAttribute('aria-controls', id);

      btn.addEventListener('click', () => {
        const open = item.classList.contains('open');
        // single-open accordion within the same list
        const list = item.closest('.faq');
        if (list) {
          $$('.faq-item.open', list).forEach((other) => {
            if (other === item) return;
            other.classList.remove('open');
            const ob = $('.faq-q', other);
            const oa = $('.faq-a', other);
            if (ob) ob.setAttribute('aria-expanded', 'false');
            if (oa) oa.style.maxHeight = '0px';
          });
        }
        item.classList.toggle('open', !open);
        btn.setAttribute('aria-expanded', open ? 'false' : 'true');
        ans.style.maxHeight = open ? '0px' : ans.scrollHeight + 40 + 'px';
      });
    });
  }

  /* ------------------------------------------------------------------ *
   * Tabs — [data-tabs] with [role=tab] + [role=tabpanel]
   * ------------------------------------------------------------------ */
  function initTabs() {
    $$('[data-tabs]').forEach((group) => {
      const tabs = $$('[role="tab"]', group);
      const select = (name) => {
        tabs.forEach((t) => t.setAttribute('aria-selected', String(t.dataset.tab === name)));
        $$('[role="tabpanel"]', group).forEach((p) => { p.hidden = p.dataset.panel !== name; });
      };
      tabs.forEach((t, i) => {
        t.addEventListener('click', () => select(t.dataset.tab));
        t.addEventListener('keydown', (e) => {
          if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
          e.preventDefault();
          const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length];
          next.focus();
          select(next.dataset.tab);
        });
      });
      const initial = tabs.find((t) => t.getAttribute('aria-selected') === 'true') || tabs[0];
      if (initial) select(initial.dataset.tab);
    });
  }

  /* ------------------------------------------------------------------ *
   * Smooth in-page anchors (respects reduced motion)
   * ------------------------------------------------------------------ */
  function initAnchors() {
    document.addEventListener('click', (e) => {
      const a = e.target.closest('a[href^="#"]');
      if (!a) return;
      // Dashboard section links are handled by dashboard.js (they swap panels).
      if (a.hasAttribute('data-section')) return;
      if (e.defaultPrevented) return;
      const id = a.getAttribute('href');
      if (!id || id === '#' || id.length < 2) return;
      const target = document.getElementById(id.slice(1));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
      target.setAttribute('tabindex', '-1');
      setTimeout(() => target.focus({ preventScroll: true }), reduceMotion ? 0 : 500);
      history.replaceState(null, '', id);
    });
  }

  /* ------------------------------------------------------------------ *
   * Prototype buttons — anything marked data-proto shows a toast
   * instead of pretending to be a working backend feature.
   * ------------------------------------------------------------------ */
  function initProtoButtons() {
    document.addEventListener('click', (e) => {
      const el = e.target.closest('[data-proto]');
      if (!el) return;
      e.preventDefault();
      const label = el.dataset.proto || 'This action';
      toast(label, 'Frontend prototype — connect an AI provider to make it live.', 'info');
    });
  }

  /* ------------------------------------------------------------------ *
   * Lazy-loading safety net + current year stamp
   * ------------------------------------------------------------------ */
  function initMisc() {
    $$('img').forEach((img) => {
      if (!img.hasAttribute('loading') && !img.dataset.eager) img.loading = 'lazy';
      if (!img.hasAttribute('decoding')) img.decoding = 'async';
    });
    $$('[data-year]').forEach((el) => { el.textContent = String(new Date().getFullYear()); });
  }

  /* ------------------------------------------------------------------ *
   * Boot
   * ------------------------------------------------------------------ */
  function boot() {
    initNav();
    initReveal();
    initCounters();
    initProgress();
    initColumns();
    initSpotlight();
    initFaq();
    initTabs();
    initAnchors();
    initProtoButtons();
    initMisc();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.ZERA = Object.assign(window.ZERA || {}, { toast, $, $$, reduceMotion });
})();
