# ZERA — AI-Powered Personalized Learning Platform

**100% Free for Students · No Subscription. No Paywall. Just Smarter Learning.**

ZERA is a completely free AI-powered personalized learning platform designed for students
across **every academic field** — school, college and university, BCA and computer
applications, B.Tech and engineering, science, commerce, management, arts and humanities,
medical and health sciences, vocational and diploma courses, and other academic or
professional programmes.

This repository is the **complete production-style frontend**: seven fully built pages, a
hand-written design system, and working interactive prototypes of every AI tool.

---

## Quick start

No build step, no dependencies, no install.

**Option 1 — just open it**

```
Extract the ZIP → double-click index.html
```

Every page, style, script, font and image is local and uses relative paths, so it works
straight from the filesystem.

**Option 2 — run a local server** (recommended; matches real browser behaviour)

```bash
# Python 3
cd ZERA
python -m http.server 8000
# → open http://localhost:8000
```

```bash
# Node.js
cd ZERA
npx serve .
```

Then browse to `index.html`. Nothing else is required.

---

## Pages

| File | Page |
| --- | --- |
| `index.html` | Home — hero, what ZERA is, all AI features, how it works, tool previews, free-forever section, final CTA |
| `about.html` | About — vision, mission, why ZERA exists, principles, the free model |
| `features.html` | Features — all 11 AI tools in full detail with a visual mock for each |
| `ai-tools.html` | AI Tools — interactive doubt solver, smart quiz, study planner, analytics, mock interview |
| `dashboard.html` | Student dashboard — progress, syllabus, plan, analytics, resources, AI assistant |
| `resources.html` | Resources — 10 skill tracks with topics, project ideas and time estimates |
| `contact.html` | Contact form with live validation, plus an 8-question FAQ |

Every navigation link, footer link and in-page anchor resolves to a real destination.
There are no dead links and no placeholder pages.

---

## Project structure

```
ZERA/
├── index.html              Home
├── about.html              About
├── features.html           All 11 features
├── ai-tools.html           Interactive AI demos
├── dashboard.html          Student dashboard
├── resources.html          Skill tracks & career resources
├── contact.html            Contact form + FAQ
│
├── css/
│   ├── style.css           Design system: tokens, layout, every component
│   ├── animations.css      Keyframes, scroll-reveal, reduced-motion support
│   └── responsive.css      Breakpoints 1500 / 1180 / 1024 / 860 / 640 / 420 + print
│
├── js/
│   ├── main.js             Nav, scroll reveal, counters, progress bars, tabs, FAQ, toasts
│   ├── interactions.js     Doubt solver, quiz engine, study planner, form validation
│   └── dashboard.js        Dashboard sections, syllabus ring, streak grid, assistant
│
├── assets/
│   ├── fonts/              Inter + Space Grotesk (WOFF2, self-hosted, SIL OFL)
│   ├── icons/              logo.svg, favicon.svg
│   └── images/             hero-orbit.svg + 4 optimised JPEGs (incl. OG card)
│
├── server/
│   └── README-API.md       Backend AI integration + API key security guide
│
├── .env.example            Placeholder environment variables (backend only)
├── LICENSE.txt             Licensing for the code and the bundled fonts
└── README.md               This file
```

Total size: roughly **1.2 MB**, including all fonts and images.

---

## What is interactive

Everything below works in the browser with no backend:

- **Sticky navigation** with a mobile hamburger panel, focus trapping and Escape to close
- **Smooth scrolling** anchors with sticky-header offset correction
- **Scroll-reveal** animations with staggered groups
- **Animated counters**, progress bars, progress rings and column charts
- **AI Doubt Solver** — type a question and get a full structured answer, with a typing
  indicator and suggested prompts (answers come from a bundled offline knowledge base)
- **Smart Quiz** — 5 questions, live scoring, per-answer explanations, progress bar,
  difficulty tags and a results screen with a restart
- **Study Plan** — tick sessions off and watch the weekly completion bar update
- **Dashboard** — switch sections, toggle syllabus units and watch the completion ring
  recalculate, generate practice drills, save resources, live relative timestamps
- **FAQ accordion**, **tabs**, **hover states** and **toast notifications**

### Prototype interactions

Actions that would need a real backend (uploading a syllabus, generating fresh notes,
starting a mock interview, submitting the contact form) are clearly labelled as
**prototype interactions**. They respond immediately with a toast explaining what would
happen in a live deployment. Nothing on this site silently does nothing, and nothing
pretends to have sent or saved data that it has not.

---

## Design system

Hand-written CSS — no framework, no CSS build step.

| | |
| --- | --- |
| **Surfaces** | Deep navy / midnight (`#05070F` → `#141A38`) with light `#F6F8FE` sections for rhythm |
| **Accents** | Electric blue `#3B7BFF`, cyan `#22D3EE`, violet `#8B5CF6`, plus mint / amber / rose for state |
| **Type** | Space Grotesk (display) + Inter (body), self-hosted WOFF2, `font-display: swap` |
| **Depth** | Glassmorphism panels, soft glows, subtle grid and dot backgrounds, layered shadows |
| **Motion** | Short, purposeful transitions; fully disabled under `prefers-reduced-motion` |

Gradients are used deliberately — on a few headline words, CTA surfaces and accent
strokes — rather than on every card.

---

## Accessibility

- Skip-to-content link on every page
- Semantic landmarks (`header`, `nav`, `main`, `section`, `footer`) and one `h1` per page
- Visible focus rings on every interactive element; full keyboard navigation
- ARIA on tabs, accordions, the mobile menu, the chat log (`aria-live`) and form errors
- Descriptive `alt` text on all content images; decorative SVGs marked `aria-hidden`
- Contrast checked against WCAG AA for body and UI text
- Complete `prefers-reduced-motion` fallback

---

## Performance

- No frameworks, no jQuery, no CDN dependencies — everything is local
- Fonts subset to Latin + Latin-Extended WOFF2 and preloaded
- Images exported as progressive JPEGs; the hero illustration is an SVG
- `loading="lazy"` and `decoding="async"` on non-critical images
- Scripts loaded with `defer`; nothing blocks first paint
- `IntersectionObserver` for reveals instead of scroll listeners

---

## SEO

Each page ships a unique `<title>`, meta description, canonical-friendly relative links,
Open Graph and Twitter card tags, and a shared social preview image
(`assets/images/og-cover.jpg`, 1200×630).

---

## Connecting a real AI provider

The AI answers on this site come from a small offline knowledge base in
`js/interactions.js`, so the demos work with no internet connection and **no API key**.

To connect a live model, read **[`server/README-API.md`](server/README-API.md)**. It covers
the architecture, suggested endpoints, reference Node and Python implementations,
free-tier provider options (Google Gemini, Groq, Hugging Face and others), environment
variables and a pre-launch security checklist.

> **The rule that guide enforces:** never hard-code a secret API key into HTML, CSS or
> JavaScript. The browser calls your own backend route; your backend holds the key in an
> environment variable. There is no API key anywhere in this frontend.

---

## Content honesty

- No invented usage statistics, student counts or growth numbers anywhere on the site
- No real testimonials — the feedback quotes on the home page are explicitly labelled
  **"Sample feedback"**
- No invented contact details, addresses, phone numbers or social media accounts
- No paid tier, premium plan or upgrade prompt exists anywhere in the project
- Dashboard figures are clearly presented as a demo student profile

---

## Browser support

Current versions of Chrome, Edge, Firefox and Safari, on desktop and mobile. Uses
`IntersectionObserver`, CSS custom properties, `clamp()`, CSS grid and `:focus-visible`.

---

## Credits

Created by **Utkarsh Giri**.

Fonts: [Inter](https://github.com/rsms/inter) and
[Space Grotesk](https://github.com/floriankarsten/space-grotesk), both licensed under the
SIL Open Font License 1.1. All icons, the logo, the hero illustration and the background
artwork were produced for this project — no premium or copyrighted third-party assets are
bundled. See `LICENSE.txt`.

---

*ZERA — AI-Powered Personalized Learning Platform · 100% Free for Students*
*© 2026 ZERA. All rights reserved.*
